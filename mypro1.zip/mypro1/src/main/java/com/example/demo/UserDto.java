package com.example.demo;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size; // <--- This one is important!

public class UserDto {

    @NotBlank(message = "Email is required")
    @Email(message = "Email should be valid")
    private String email;

    @NotBlank(message = "Password is required")
    @Size(min = 6, message = "Password must be at least 6 characters long") // <--- Minimum password length
    private String password;

    private String role;

    // Getters and Setters and Constructors
    // ... (rest of your UserDto code) ...
}