package com.example.demo;

public class LoginResponse {
    private String message;
    private String role;

    // Constructor
    public LoginResponse(String message, String role) {
        this.message = message;
        this.role = role;
    }

    // Getters
    public String getMessage() {
        return message;
    }

    public String getRole() {
        return role;
    }

    // Setters (optional if you only set values in constructor)
    public void setMessage(String message) {
        this.message = message;
    }

    public void setRole(String role) {
        this.role = role;
    }
}