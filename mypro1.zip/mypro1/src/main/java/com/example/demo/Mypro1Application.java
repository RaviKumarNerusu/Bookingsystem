package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@SpringBootApplication
public class Mypro1Application implements CommandLineRunner {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    public static void main(String[] args) {
        SpringApplication.run(Mypro1Application.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        // Create default admin if not exists
        if (userRepository.findByEmail("admin@utham.com").isEmpty()) {
            User admin = new User();
            admin.setEmail("admin@utham.com");
            admin.setPassword(passwordEncoder.encode("admin123"));
            admin.setRole("ADMIN");
            userRepository.save(admin);
            System.out.println("Default admin 'admin@utham.com' created with password 'admin123'");
        }
    }
}