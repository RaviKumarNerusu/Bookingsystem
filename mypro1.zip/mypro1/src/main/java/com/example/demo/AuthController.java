package com.example.demo;

import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;
import org.springframework.transaction.annotation.Transactional; // <<< ADD THIS IMPORT

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final UserRepository userRepository;
    private final BCryptPasswordEncoder passwordEncoder;

    public AuthController(UserRepository userRepository, BCryptPasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @PostMapping("/register")
    @Transactional // <<< ADD THIS ANNOTATION
    public ResponseEntity<Map<String, String>> register(@Valid @RequestBody UserDto dto) {
        // 1. Check if user with this email already exists
        if (userRepository.findByEmail(dto.getEmail()).isPresent()) {
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("message", "Email already exists!");
            return ResponseEntity.status(HttpStatus.CONFLICT).body(errorResponse);
        }

        // 2. Create new User entity
        User user = new User();
        user.setEmail(dto.getEmail());
        // 3. CRITICAL: Hash the password before saving to the database
        user.setPassword(passwordEncoder.encode(dto.getPassword()));
        user.setRole("USER"); // Default role for new registrations

        // 4. Save the user to the database
        userRepository.save(user);
        System.out.println("DEBUG: User registered and saved to DB: " + user.getEmail());
        System.out.println("DEBUG: Hashed password in DB: " + user.getPassword());

        Map<String, String> successResponse = new HashMap<>();
        successResponse.put("message", "User registered successfully");
        return ResponseEntity.ok(successResponse);
    }

    @PostMapping("/login")
    // @Transactional is usually not needed for read-only operations like login, but won't hurt.
    // For login, you typically don't modify the database.
    public ResponseEntity<?> login(@RequestBody LoginRequest loginRequest) {
        System.out.println("DEBUG: Login attempt for email: " + loginRequest.getEmail());
        // WARNING: Do NOT log plain passwords in production systems! This is for debugging only.
        System.out.println("DEBUG: Provided password (raw): " + loginRequest.getPassword());

        // 1. Find user by email
        Optional<User> userOptional = userRepository.findByEmail(loginRequest.getEmail());

        // 2. If user not found (email doesn't exist)
        if (userOptional.isEmpty()) {
            System.out.println("DEBUG: User not found for email: " + loginRequest.getEmail());
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of("message", "Invalid email or password"));
        }

        User user = userOptional.get();
        System.out.println("DEBUG: User found in DB: " + user.getEmail() + ", Role: " + user.getRole());
        System.out.println("DEBUG: Stored hashed password from DB: " + user.getPassword());

        // 3. CRITICAL: Compare provided password with stored hashed password
        boolean passwordMatches = passwordEncoder.matches(loginRequest.getPassword(), user.getPassword());
        System.out.println("DEBUG: Password match result: " + passwordMatches);

        // 4. If passwords do not match
        if (!passwordMatches) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of("message", "Invalid email or password"));
        }

        // 5. If passwords match, authentication is successful
        System.out.println("DEBUG: Login successful for user: " + user.getEmail());
        LoginResponse response = new LoginResponse(
            user.getRole().equals("ADMIN") ? "Admin login successful" : "User login successful",
            user.getRole()
        );
        return ResponseEntity.ok(response);
    }
}