package com.example.demo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public BCryptPasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .csrf().disable() // Disable CSRF for simplicity (use with caution in production)
            .authorizeHttpRequests(authorize -> authorize
                // Permit all OPTIONS requests (preflight requests) to allow CORS handshake
                .requestMatchers(HttpMethod.OPTIONS, "/**").permitAll()
                // Allow unauthenticated access to auth endpoints (register/login)
                .requestMatchers("/api/auth/**").permitAll() // This is correctly set up
                // All other requests require authentication
                .anyRequest().authenticated()
            );
        return http.build();
    }

    // CORS Configuration for Spring MVC
    @Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurer() {
            @Override
            public void addCorsMappings(CorsRegistry registry) {
                registry.addMapping("/api/**") // Apply CORS to all /api endpoints
                        .allowedOrigins("http://localhost:5173") // Your React app's URL
                        .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS") // Include OPTIONS
                        .allowedHeaders("*") // Allow all headers
                        .allowCredentials(true); // Allow sending of cookies/auth headers
            }
        };
    }
}