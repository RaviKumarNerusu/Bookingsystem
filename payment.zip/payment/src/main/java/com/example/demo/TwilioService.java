package com.example.demo;

import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class TwilioService {

    // You can remove these two lines, as Twilio.init is now handled in TwilioConfig
    // @Value("${twilio.account.sid}")
    // private String accountSid;
    // @Value("${twilio.auth.token}")
    // private String authToken;

    @Value("${twilio.phone.number}")
    private String twilioPhoneNumber;

    @Value("${admin.phone.number}")
    private String adminPhoneNumber;

    public void sendAdminSMS(String confirmationId, double amount, String transactionId, String item) {
        // REMOVE THIS LINE! Twilio is now initialized in TwilioConfig.java
        // Twilio.init(accountSid, authToken);

        String baseUrl = "http://localhost:8080/api/confirm-payment"; // Corrected port to 8080
        String yesLink = String.format("%s?confirmationId=%s&response=yes", baseUrl, confirmationId);
        String noLink = String.format("%s?confirmationId=%s&response=no", baseUrl, confirmationId);

        String messageBody = String.format(
            "Payment of ₹%.2f received. Transaction ID: %s. Item: %s. Confirm: Yes (%s) | No (%s)",
            amount, transactionId, item, yesLink, noLink
        );

        try {
            Message.creator(
                new PhoneNumber(adminPhoneNumber),
                new PhoneNumber(twilioPhoneNumber),
                messageBody
            ).create();
            System.out.println("SMS sent successfully to admin: " + adminPhoneNumber);
        } catch (com.twilio.exception.ApiException e) { // Catch Twilio's specific API exception
            System.err.println("Twilio API error sending SMS: " + e.getMessage());
            e.printStackTrace();
            // Handle specific Twilio API errors (e.g., invalid number, insufficient balance)
        } catch (Exception e) {
            System.err.println("General error sending SMS: " + e.getMessage());
            e.printStackTrace();
        }
    }
}