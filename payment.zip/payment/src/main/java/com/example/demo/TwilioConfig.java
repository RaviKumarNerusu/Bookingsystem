package com.example.demo;

import com.twilio.Twilio;
import jakarta.annotation.PostConstruct; // Use jakarta.annotation.PostConstruct for Spring Boot 3+
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration // Marks this class as a Spring configuration class
public class TwilioConfig {

    @Value("${twilio.account.sid}")
    private String accountSid; // Spring will inject the value from application.properties

    @Value("${twilio.auth.token}")
    private String authToken; // Spring will inject the value from application.properties

    // This method will be called automatically by Spring after the bean is constructed
    // and after all @Value annotations have been processed.
    @PostConstruct
    public void initTwilio() {
        Twilio.init(accountSid, authToken);
        System.out.println("Twilio SDK initialized successfully with Account SID: " + accountSid);
    }
}