package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class PaymentController {

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private TwilioService twilioService;

    @PostMapping("/initiate-payment")
    public ResponseEntity<Map<String, String>> initiatePayment(@RequestBody Map<String, Object> paymentDetails) {
        String confirmationId = "CONF" + System.currentTimeMillis();
        String transactionId = "TXN" + System.currentTimeMillis();
        double amount = Double.parseDouble(paymentDetails.get("amount").toString());
        String item = paymentDetails.get("item").toString();

        Payment payment = new Payment(confirmationId, transactionId, amount, item);
        paymentRepository.save(payment);

        twilioService.sendAdminSMS(confirmationId, amount, transactionId, item);

        Map<String, String> response = new HashMap<>();
        response.put("confirmationId", confirmationId);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/confirm-payment")
    public ResponseEntity<String> confirmPayment(
        @RequestParam String confirmationId,
        @RequestParam String response
    ) {
        Payment payment = paymentRepository.findById(confirmationId).orElse(null);
        if (payment == null) {
            return ResponseEntity.badRequest().body("Invalid confirmation ID");
        }
        payment.setAdminResponse(response);
        payment.setUpdatedAt(LocalDateTime.now());
        paymentRepository.save(payment);
        return ResponseEntity.ok("Payment confirmation updated");
    }

    @GetMapping("/check-confirmation")
    public ResponseEntity<Map<String, String>> checkConfirmation(@RequestParam String confirmationId) {
        Payment payment = paymentRepository.findById(confirmationId).orElse(null);
        Map<String, String> response = new HashMap<>();
        if (payment == null) {
            response.put("error", "Invalid confirmation ID");
            return ResponseEntity.badRequest().body(response);
        }
        response.put("adminResponse", payment.getAdminResponse() != null ? payment.getAdminResponse() : "");
        response.put("transactionId", payment.getTransactionId());
        response.put("amount", String.format("%.2f", payment.getAmount()));
        response.put("item", payment.getItem());
        response.put("date", payment.getCreatedAt().toLocalDate().toString());
        response.put("time", payment.getCreatedAt().toLocalTime().toString());
        return ResponseEntity.ok(response);
    }
}